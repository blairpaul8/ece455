part2b.o: part2b.c part2b.h \
 /usr/lib/gcc/arm-none-eabi/15.3.1/include/stdint.h \
 /usr/arm-none-eabi/include/stdint.h \
 /usr/arm-none-eabi/include/machine/_default_types.h \
 /usr/arm-none-eabi/include/sys/features.h \
 /usr/arm-none-eabi/include/_newlib_version.h \
 /usr/arm-none-eabi/include/sys/_intsup.h \
 /usr/arm-none-eabi/include/sys/_stdint.h tm4c123gh6pm.h
